// GAUGE.h
// This is a simple example for Arduinos to
// display a simple Analog Meter and a Digital Meter
// (C) 2018 Martin Michael
// I will replace the Font with a Digital Font sonn as possible
#ifndef _GAUGE_h
#define _GAUGE_h

#if defined(ARDUINO) && ARDUINO >= 100
	#include "arduino.h"
#else
	#include "WProgram.h"
#endif

#include <MCUFRIEND_kbv.h>
#include <Adafruit_GFX.h> //include TinyScreen library
#include <stdint.h>

#include "FreeMonoBold.cpp"

const char aUnit[7][3] = { "", "mA", "mV", "O", "kO", "MO", "kV" };

enum Unit {

	Without  = 0,
	millyAmp = 1,
    millyVolt = 2,
	Ohm       = 3,
	KiloOhm   = 4,
	MegaOhm   = 5,
	kV        = 6
};


enum
{
	GaugeCenterX = 70,
	GaugeCenterY = 70,
	GaugeBackgroundColor = ILI9341_BEIGE,

	GaugeCircleRadius = 50,
	GaugeCircleRadiusColor = ILI9341_GOLD,
	GaugePointerLowColor = ILI9341_DARKGREEN,

	GaugePointerMidColor = ILI9341_CRIMSON,
	GaugePointerHighColor = ILI9341_RED,
	GaugePointerHubColor = ILI9341_NAVY,
	GaugeFrameColor = ILI9341_LIGHTBLUE,
	GaugeFrameColorLowerLine = ILI9341_DARKBLUE,
	GaugeFrameSize = 52,
	GaugeFrameHeight = GaugeFrameSize +12,

	DigiTextColor = ILI9341_BLUEVIOLET,

	DigiBkColor = ILI9341_YELLOWGREEN,

	 DigiX = 5,
	 DigiY = 100,
	 DigiW = 130,
	 DigiH = 25
};

#define ScreenHeight 240
#define ScreenWidth  320

class GAUGEClass
{
private:
	float _NewValueAnalog;
	float _OldValueAnalog;
	float _NewValueDigi;
	float _OldValueDigi;
	 Adafruit_GFX *_tft = nullptr;
	 uint16_t _BackColor;
	 uint16_t _TextColor;
	 bool     _ValueChanged;
	 
	 char Buffer[35];
	 
	 uint16_t _x1;
	 uint16_t _y1;

	 uint16_t _x2;
	 uint16_t _y2;

	 Unit _Unit;
	 char sUnit[3];
	 void Draw_Gauge_Circle(int x, int y, int r);
	 void draw_Zeiger(int x, int y, int r, float Value, bool Clean);
	 void DrawDigiValue(float Value, bool Clean);

 public:
	
	void initAnalog(Adafruit_GFX *tft, uint16_t BackColor);
	void initDigi(Adafruit_GFX *tft, uint16_t BackColor, uint16_t TextColor, Unit U);
	void SetAnalogValue( float Value);
	void SetDigiValue(float Value);
	
	
	
};

extern GAUGEClass GAUGE;

#endif

