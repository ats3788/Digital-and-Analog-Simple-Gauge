
#include "Gauge.h"


void GAUGEClass::initAnalog(Adafruit_GFX *tft, uint16_t BackColor)
{
	_tft = tft;
	_BackColor = BackColor;
	
	_OldValueAnalog = 0.0;
	_NewValueAnalog = 0.0;

	Draw_Gauge_Circle(GaugeCenterX,	GaugeCenterY , GaugeCircleRadius);
	
}


void GAUGEClass::Draw_Gauge_Circle(int x, int y, int r)
{
	char Buffer[30];
	
	_tft->fillRect(x - GaugeFrameSize, y - GaugeFrameSize, GaugeFrameSize * 2, GaugeFrameHeight, _BackColor);
	_tft->drawRect(x - GaugeFrameSize, y - GaugeFrameSize, GaugeFrameSize *2, GaugeFrameHeight, GaugeFrameColor);

	double dtheta = 2 * M_PI / 8 / r;
	int x1 = x + r;   // x1 Start x + radius
	int x2;
	int y1 = y;     // y1 is theCenter of Circle
	int y2;
	int n = 2 * M_PI / dtheta;
	bool One = true;
	for (int i = 199; i < n; i++)
	{
		double theta = i * dtheta;
		x2 = int(x + r * cos(theta)); // Here we get --> X2
		y2 = int(y + r * sin(theta)); // Here we get --> Y2
		
		if (One) {
			_tft->drawLine(x1,y1,x2,y2, GaugeFrameColorLowerLine);
			_x1 = x1;
			_y1 = y1;
			_x2 = x2;
			_y2 = y2;
			One = false;
		}
		
		x1 = x2; y1 = y2;
		_tft->drawPixel(x2, y2, GaugeCircleRadiusColor);

		sprintf(Buffer, "x1 %d  x2 %d y1 %d y2 %d ", x1, x2, y1, y2);
		Serial.print(Buffer);
	}
}



void GAUGEClass::draw_Zeiger(int x, int y, int r, float Value, bool Clean)
{
	char Buffer[30];
	uint16_t Farbe;

	r--;

	if (Value > 50 & Value < 100)
		Farbe = GaugePointerMidColor;

	if (Value < 50)
		Farbe = GaugePointerLowColor;

	if (Value > 100)
		Farbe = GaugePointerHighColor;

	if (Clean)
		Farbe = GaugeBackgroundColor;


	Value = Value + 199;
	// Inspired by https://stackoverflow.com/questions/13120884/drawing-big-circles-from-scratch
	double dtheta = 2 * M_PI / 8 / r;
	int x1 = x + r;   // x1 Start x + radius
	int x2;
	int y1 = y;     // y1 is theCenter of Circle
	int y2;
	int n = 2 * M_PI / dtheta;

	double theta = Value * dtheta;
	x2 = int(x + r * cos(theta)); // Here we get --> X2
	y2 = int(y + r * sin(theta)); // Here we get --> Y2

	x1 = x2;
	y1 = y2;
	_tft->drawLine(x, y, x2, y2, Farbe);


	_tft->fillCircle(x, y, 4, GaugePointerHubColor);
	_tft->drawLine(_x1, _y1, _x2, _y2, GaugeFrameColorLowerLine);
}


void GAUGEClass::SetAnalogValue(float Value)
{
	_NewValueAnalog = Value;
	draw_Zeiger(GaugeCenterX, GaugeCenterY, GaugeCircleRadius, _OldValueAnalog, true);

	draw_Zeiger(GaugeCenterX, GaugeCenterY, GaugeCircleRadius, _NewValueAnalog, false );

	_OldValueAnalog = _NewValueAnalog;


}


//////////////////////////////////////////////////////////////////////////////////////
///    Digi Part og the Gauge ********************************************************
//////////////////////////////////////////////////////////////////////////////////////

void GAUGEClass::initDigi(Adafruit_GFX *tft, uint16_t BackColor, uint16_t TextColor, Unit U)
{
	_TextColor = TextColor;
	if (_tft != nullptr)
		_tft = tft;
	_Unit = U;

	strcpy(sUnit, aUnit[U]);
	_tft->fillRoundRect(DigiX, DigiY, DigiW, DigiH, 5,DigiBkColor);
	_OldValueDigi = 0.0;
	_NewValueDigi = 0.0;
	_tft->setFont(&_FreeMonoBold_);
	_tft->setTextColor(TextColor);
	SetDigiValue(0.0);
	

}

void GAUGEClass::DrawDigiValue(float Value, bool Clean)
{
	char * Puffer;
	Puffer = new char[10]; // Memory Allocation 
	dtostrf(Value, 1, 2, Puffer); // Float to C-String
	if (Value < 10) 
		sprintf(Buffer, "00%s", Puffer);// Add 2 front Zeros
	if (Value > 10 & Value < 100) // if Value is bigger then 10
									
	sprintf(Buffer, "0%s", Puffer);    // and smaller then 100
	_tft->setCursor(DigiX + 5, DigiY + 20);

	if (Clean)
		_tft->setTextColor(DigiBkColor);// to Clear the Older Value
	else
		_tft->setTextColor(DigiTextColor);

	_tft->print(Buffer);  
	_tft->print(sUnit);
	delete[] Puffer;// Give the Memory Back;
}


void GAUGEClass::SetDigiValue(float Value)
{

	_NewValueDigi = Value;
	DrawDigiValue(_OldValueDigi, true);

	DrawDigiValue(_NewValueDigi, false);

	_OldValueDigi = _NewValueDigi;
}






GAUGEClass GAUGE;

