
#include "BigGAUGE.h"


void BigGAUGEClass::initAnalog(Adafruit_GFX *tft, uint16_t BackColor)
{
	_tft = tft;
	_BackColor = BackColor;
	
	_OldValueAnalog = 0.0;
	_NewValueAnalog = 0.0;

	Draw_BigGAUGE_Circle(BigGAUGECenterX,	BigGAUGECenterY , BigGAUGECircleRadius);
	
}


void BigGAUGEClass::Draw_BigGAUGE_Circle(int x, int y, int r)
{
	char Buffer[30];
	
	_tft->fillRect(x - BigGAUGEFrameSize, y - BigGAUGEFrameSize, BigGAUGEFrameSize * 2, BigGAUGEFrameHeight, _BackColor);
	_tft->drawRect(x - BigGAUGEFrameSize, y - BigGAUGEFrameSize, BigGAUGEFrameSize *2, BigGAUGEFrameHeight, BigGAUGEFrameColor);

	double dtheta = 2 * M_PI / 8 / r;
	int x1 = x + r;   // x1 Start x + radius
	int x2;
	int y1 = y;     // y1 is theCenter of Circle
	int y2;
	int n = 2 * M_PI / dtheta;
	bool One = true;
	for (int i = BigGAUGESizeOfGauge; i < n; i++)
	{
		double theta = i * dtheta;
		x2 = int(x + r * cos(theta)); // Here we get --> X2
		y2 = int(y + r * sin(theta)); // Here we get --> Y2
		
		if (One) {
			_tft->drawLine(x1,y1,x2,y2, BigGAUGEFrameColorLowerLine);
			_x1 = x1;
			_y1 = y1;
			_x2 = x2;
			_y2 = y2;
			One = false;
		}
		
		x1 = x2; y1 = y2;
		_tft->drawPixel(x2, y2, BigGAUGECircleRadiusColor);

		sprintf(Buffer, "x1 %d  x2 %d y1 %d y2 %d ", x1, x2, y1, y2);
		Serial.print(Buffer);
	}
}



void BigGAUGEClass::draw_Zeiger(int x, int y, int r, float Value, bool Clean)
{
	uint16_t Farbe;
	char * Buffer;
	Buffer = new char[20]; // Memory Allocation 

	r--;

	if (Value > 150 & Value < 250)
		Farbe = BigGAUGEPointerMidColor;

	if (Value < 150)
		Farbe = BigGAUGEPointerLowColor;

	if (Value > 250)
		Farbe = BigGAUGEPointerHighColor;

	if (Clean)
		Farbe = BigGAUGEBackgroundColor;


	Value = Value + BigGAUGESizeOfGauge;
	// Inspired by https://stackoverflow.com/questions/13120884/drawing-big-circles-from-scratch
	double dtheta = 2 * M_PI / 8 / r;
	int x1 = x + r;   // x1 Start x + radius
	int x2;
	int y1 = y;     // y1 is theCenter of Circle
	int y2;
	int n = 2 * M_PI / dtheta;

	double theta = Value * dtheta;
	x2 = int(x + r * cos(theta)); // Here we get --> X2
	y2 = int(y + r * sin(theta)); // Here we get --> Y2

	x1 = x2;
	y1 = y2;
	_tft->drawLine(x, y, x2, y2, Farbe);

	_tft->fillCircle(x, y, 4, BigGAUGEPointerHubColor);
	_tft->drawLine(_x1, _y1, _x2, _y2, BigGAUGEFrameColorLowerLine);

	delete[] Buffer;// Give the Memory Back;
}


void BigGAUGEClass::SetAnalogValue(float Value)
{
	_NewValueAnalog = Value;
	draw_Zeiger(BigGAUGECenterX, BigGAUGECenterY, BigGAUGECircleRadius, _OldValueAnalog, true);

	draw_Zeiger(BigGAUGECenterX, BigGAUGECenterY, BigGAUGECircleRadius, _NewValueAnalog, false );

	_OldValueAnalog = _NewValueAnalog;


}


//////////////////////////////////////////////////////////////////////////////////////
///    Digi Part og the BigGAUGE ********************************************************
//////////////////////////////////////////////////////////////////////////////////////

void BigGAUGEClass::initDigi(Adafruit_GFX *tft, uint16_t BackColor, uint16_t TextColor, Unit U)
{
	_TextColor = TextColor;
	if (_tft != nullptr)
		_tft = tft;
	_Unit = U;

	strcpy(sUnit, aUnit[U]);
	_tft->fillRoundRect(DigiX, DigiY, DigiW, DigiH, 5,DigiBkColor);
	_OldValueDigi = 0.0;
	_NewValueDigi = 0.0;
	_tft->setFont(&_FreeMonoBold_);
	_tft->setTextColor(TextColor);
	SetDigiValue(0.0);
	

}

void BigGAUGEClass::DrawDigiValue(float Value, bool Clean)
{
	char * Puffer;
	Puffer = new char[10]; // Memory Allocation 
	dtostrf(Value, 1, 2, Puffer); // Float to C-String
	if (Value < 10) 
		sprintf(Buffer, "00%s", Puffer);// Add 2 front Zeros
	if (Value > 10 & Value < 100) // if Value is bigger then 10
									
	sprintf(Buffer, "0%s", Puffer);    // and smaller then 100
	_tft->setCursor(DigiX + 5, DigiY + 20);

	if (Clean)
		_tft->setTextColor(DigiBkColor);// to Clear the Older Value
	else
		_tft->setTextColor(DigiTextColor);

	_tft->print(Buffer);  
	_tft->print(sUnit);
	delete[] Puffer;// Give the Memory Back;
}


void BigGAUGEClass::SetDigiValue(float Value)
{

	_NewValueDigi = Value;
	DrawDigiValue(_OldValueDigi, true);

	DrawDigiValue(_NewValueDigi, false);

	_OldValueDigi = _NewValueDigi;
}






BigGAUGEClass BigGAUGE;

